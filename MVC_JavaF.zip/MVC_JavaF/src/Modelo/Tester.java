package Modelo;

import java.util.ArrayList;
import java.util.List;

public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i,j;
		MDB administradorBD =  new MDB();
		List<ArrayList<String>> datosObtenidos= new ArrayList<ArrayList<String>>();
		ArrayList<String> renglonObtenido = new ArrayList<String>();
		String leyenda;
                //insertar
                //leyenda= administradorBD.registrarAlta("tbusuarios", "null, 'Pedro','usuarioMartínez',1234");//Original
                leyenda= administradorBD.registrarAlta("seguimiento_clientes", "null, 2,'Puebla','Pedro','Licenciado','Calle1','Pachuca','12','jose@usuario',551121110,778815227,02,'Unica','2022-01-21',10,125.25,500.25,10,375.0,'Mensual','2021-01-21 18:00:00','Realizado','2021-01-31 18:00:00','Realizado','2021-02-10 18:00:00','Realizado','2021-02-21 18:00:00','Pendiente'");                
                System.out.println(leyenda);
                
                //modificar
	//leyenda = administradorBD.modificarRegistro("TbEquipo", "nombre='lapiz' , descripcion = 'digital' ,  cantidad= '4'", "id = 5");
      //     System.out.println(leyenda);
                
                //Borrar
         //  leyenda = administradorBD.borrarRegistro("TbUsuarios", "id = 3");
           //   System.out.println(leyenda);
		
                //consulta
		/*datosObtenidos = administradorBD.consultarDatos("tbUsuarios", "id , nombre,apPaterno, psw", "id=1");
                  System.out.println(leyenda);
		for(i=0;i<datosObtenidos.size();i++)
		{
                    renglonObtenido = datosObtenidos.get(i);
                    for(j=0;j<renglonObtenido.size();j++){
			System.out.print(renglonObtenido.get(j) + " ");
                    }
                    System.out.println();
		}*/
        }
}
